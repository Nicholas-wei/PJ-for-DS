﻿#include<iostream>
#include"ticket_info.h"
#include"graph.h"
#include<iomanip>
#define max_n 1024
//12.17完成类定义，文件读写输出,读入输出鲁棒性检测ticket_info.h
//12.18完成时刻表和图的连接，从文件读入并输入到图，采用邻接表储存
//12.18思考问题：
//1.隔一天或者多天到达系列车票时间处理办法（添加天数输入）解决
//2.采用每次读取所有票价信息运算到内存邻接表的方法运算(解决）
//3.利用Dijkstra算法的时候，要做两种考虑
//一种是cost_value，直接计算即可
//第二种是time_value，这个要考虑中转时间。目前想到的办法是新建一个临时nodetable表格并修改time_value变量大小，修改为路上花费+(departure-last_arrivial)
//这里必须做假设是每天发车时间固定
//最后还是利用Dijkstra算法得到结果
//12.19完成Dijkstra算法，基于money
//完成过程中对于money添加了基于方式的选择，时间11：50
//完成由path构造路径的函数vector<vector<int>> NewPath(int v, int path[], int n)时间12:13 次饭
//测试三组数据13：41
//突然想到是不是要输出全部的Dijkstra算法得到的最简单路径？那就太麻烦了，那就不写了
//12.20完成Dijkstra算法，基于time 9:40开始
//基于time第一组数据测试完毕11：40
//基于time第二组数据测试完毕11：45 eating!
//12：14回来发现一个bug，关于数组下标的问题，12：34修改完毕,并测试第三组数据,明天再写！
//12.22添加删除城市逻辑18：23----19:02,对于添加城市，必须保证为在添加ticket的时候才能添加。即不能添加孤立城市
//12.23添加平行边信息，完成基于money和输出19:12



void clean_ch(char* ch, int n)
{
	for (int i = 0; i < n; i++)
	{
		ch[i] = '0';
	}
}


void time_compresion(graphlnk graph,char* src,char* dst,int way,int n)
{
	vector<vector<element>>all_path;
	int* dist = new int[n];
	element* path = new element[n];
	bool reachable = false;
	reachable = graph.find_shortest_path_with_time(src, dst, dist, path, way);
	if (reachable)
	{
		n = graph.size();
		all_path = graph.NewPath(src, path, n, way);
		graph.print_path(dst, all_path, way,1);
	}
	/*else
	{
		cout << "对于选择的交通工具，无法到达该城市" << endl;
		return;
	}*/
}



void money_compresion(graphlnk graph, char* src, char* dst, int way, int n)
{
	vector<vector<element>>all_path;
	int* dist = new int[n];
	element* path = new element[n];
	bool reachable = false;
	reachable = graph.find_shortest_path_with_money(src, dst, dist, path, way);
	if (reachable)
	{
		n = graph.size();
		all_path = graph.NewPath(src, path, n, way);
		graph.print_path(dst, all_path, way,0);
	}
	else
	{
		cout << "对于选择的交通工具，无法到达该城市" << endl;
		return;
	}
	
}


void route_compression(graphlnk graph, char* src, char* dst, int way, int n)
{
	vector<vector<element>>all_path;
	element* path = new element[n];
	bool reachable = false;
	for (int i = 0; i < n; i++)
	{
		path[i].data = -1;
	}
	reachable = graph.find_shortest_path_with_less_transit(src, dst, path, way);
	if (reachable)
	{
		n = graph.size();
		all_path = graph.NewPath(src, path, n, way);
		graph.print_path(dst, all_path, way, 0);//此时还是输出总金额
	}
	else
	{
		cout << "对于选择的交通工具，无法到达该城市" << endl;
		return;
	}
}


void user_panel()
{
	ticket_info ticket;
	graphlnk graph;
	char src[50];
	char dst[50];
	string src_string;
	string dst_string;
	int choice = 0;
	int way = 0;
	int* dist = new int[1024];
	element* path = new element[1024];
	int n = 0;
	

	while (1)
	{
		cout << "***********交通查询程序***********" << endl;
		cout << "以下功能可以被使用，请输入编号来使用之" << endl;
		cout << std::left << setw(40) << "1.显示当前交通路径" << std::left << setw(40) << "2.删除路径（会同时打印路径表格）" << endl;
		cout << std::left << setw(40) << "3.添加路径,城市" << std::left << setw(40) << "4.删除城市（同时会删除和该城市出发和到达的所有相关路径)" << endl;
		cout << std::left << setw(40) << "5.查找路线,基于时间最短" << std::left << setw(40) << "6.查找路线，基于价格最低" << endl;
		cout << std::left << setw(40) << "7.查找路线，基于中转最少";
		cout << std::left << setw(40) << "8.显示从某城市出发所有航班，列车信息" << setw(40) << "9.显示设计细节" << endl;
		cout << std::left << setw(40) << "输入 0 退出" << endl;
		while (1)
		{
			cout << "请输入用户面板选择,输入0退出" << endl;
			if (cin >> choice)break;
			else
			{
				cout << "输入错误，请重新输入\n";
				cin.clear();
				cin.ignore();
			}
		}
		switch (choice)
		{
		case 0:
			cout << "bye" << endl;
			cout << "期末快乐" << endl;
			exit(0);
		case 1:
			ticket.print_ticket_table();
			break;
		case 2:
			ticket.delete_ticket();
			cout << "删除路径完毕！" << endl;
			//graph.building_graph();
			break;
		case 3:
			ticket.add_ticket();
			//graph.building_graph();
			break;
		case 4:
			graph.building_graph();
			cout << "目前有以下城市可以删除：" << endl;
			graph.print_city_name();
			ticket.delete_city();
			//graph.building_graph();
			graph.empty();
			break;
		case 5:
			graph.building_graph();
			clean_ch(src, 50);
			clean_ch(dst, 50);
			cout << "请输入两个城市名称:" << endl;
			cout << "城市1(出发城市)：";
			cin >> src;
			cout << "城市2(目标城市)：";
			cin >> dst;
			cout << "请输入交通方式,0表示火车，1表示飞机";
			while (1)
			{
				if (cin >> way && (way == 0 || way == 1))break;
				else
				{
					cout << "输入错误，请重新输入，路径只能输入1或者0\n";
					cin.clear();
					cin.ignore();
				}
			}
			time_compresion(graph, src, dst, way, graph.size());
			graph.empty();
			break;
		case 6:
			graph.building_graph();
			clean_ch(src, 50);
			clean_ch(dst, 50);
			cout << "请输入两个城市名称:" << endl;
			cout << "城市1(出发城市)：";
			cin >> src;
			cout << "城市2(目标城市)：";
			cin >> dst;
			cout << "请输入交通方式,0表示火车，1表示飞机";
			while (1)
			{
				if (cin >> way && (way == 0 || way == 1))break;
				else
				{
					cout << "输入错误，请重新输入，路径只能输入1或者0\n";
					cin.clear();
					cin.ignore();
				}
			}
			money_compresion(graph, src, dst, way, graph.size());
			graph.empty();
			break;
		case 7:
			graph.building_graph();
			clean_ch(src, 50);
			clean_ch(dst, 50);
			cout << "请输入两个城市名称:" << endl;
			cout << "城市1(出发城市)：";
			cin >> src;
			cout << "城市2(目标城市)：";
			cin >> dst;
			cout << "请输入交通方式,0表示火车，1表示飞机";
			while (1)
			{
				if (cin >> way && (way == 0 || way == 1))break;
				else
				{
					cout << "输入错误，请重新输入，路径只能输入1或者0\n";
					cin.clear();
					cin.ignore();
				}
			}
			route_compression(graph, src, dst, way, graph.size());
			break;
		case 8:
			graph.building_graph();
			clean_ch(src, 50);
			cout << "目前有以下城市:" << endl;
			graph.print_city_name();
			cout << "请输入想要查询的城市名称:";
			cin >> src;
			graph.show_city_routes(src);
			graph.empty();
			break;
		case 9:
			cout << "***************************************************************************************************************************" << endl;
			cout << "**1.基于时间的计算中,基于Djkstra算法，按照从该地到达下一目的地最早的一趟列车/飞机的起始时间作为判断依据计算              **" << endl;
			cout << "**2.可以满足跨多天的航线                                                                                                 **" << endl;
			cout << "**3.在基于最短时间的方法上，最终只显示最短时间，基于最少价格最终只显示最少价格                                           **" << endl;
			cout << "**4.如果有多条完全符合题意的路径，只能打印其中的一条                                                                     **" << endl;
			cout << "**5.文件存储部分再用每次添加写入ticket_info.txt文件来实现储存，对于更新完的ticket_info在下一次用户查询的时候会重新建立图 **" << endl;
			cout << "**That's all,thanks for reading!                                                                                         **" << endl;
			cout << "***************************************************************************************************************************" << endl;
			break;
		default:
			cout << "输入错误,请重新输入,编号为0到9" << endl;
			break;
		
		}
	}

}
int main()
{
	user_panel();
}