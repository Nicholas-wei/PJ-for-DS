#pragma once
#include<iostream>
#include<vector>
#include<fstream>
#include<queue>
const int MAXVALUE=999999;
using namespace std;
//�����ڽӱ���ʽ����
struct my_time
{
	int hour=-1;//��ʼ��
	int minute=-1;//��ʼ��
	my_time() { hour = -1; minute = -1; }
};


bool equal(my_time t1, my_time t2) { return (t1.hour == t2.hour && t1.minute == t2.minute); }



struct ticket_info_for_graph
{
	my_time departure_time;
	my_time arrivial_time;
	int money = 0;
	int timespan = -1;
};
struct element
{
	int data;
	int timespan =0;
	ticket_info_for_graph ticket;
	void clean()
	{
		data = 0;
		my_time t;
		t.hour = -1;
		t.minute = -1;
		ticket.arrivial_time = t;
		ticket.departure_time = t;
	}
};

struct edge//����ο��廪�̲�
{
	my_time arrivial_time;//����ʱ��
	my_time departure_time;//����ʱ��
	int type;//��ͨ��������
	int time;//��;����ʱ��
	int money;//�۸�
	char dest[50]="0";//Ŀ�ĵ�
	edge* next;//��һ����
	edge() { time = 0; money = 0; next = nullptr; }//��ʼ��
};


struct vertex
{
	char name[50];
	edge* adj;
	my_time chosen_arrivial;
};


class graphlnk
{
public:
	bool building_graph();//���ļ�����ticket_info������ͼ
	bool find_shortest_path_with_money(char* src, char* dst, int dist[], element path[], int way);
	bool find_shortest_path_with_time(char* src, char* dst, int dist[], element path[], int way);
	bool find_shortest_path_with_less_transit(char* src, char* dst, element path[], int way);//ʵ����ת����·�����
	void show_city_routes(char* src);//��ʾ�ó��г����������г��ɻ���Ϣ
	int size() { return Vertices_num; }
	vector<vector<element>> NewPath(char* src, element path[], int n,int way);
	void print_path(char* dst,vector < vector<element>> path,int way,int sign);
	void empty() { nodetable.clear(); }//���
	void print_city_name();

private:
	int Vertices_num;
	int get_index(char* src);//�õ��������е��±�
	bool print_name_by_index(int index);
	vector<vertex> nodetable;
	bool insert(char* src, char* dst, int money, int time, int type, my_time dep_time, my_time arriv_time);
	int getweight_time(char* src, char* dst,int way, element path, my_time arriv_time, edge*& arg_edge);//����ʱ��Ȩֵ
	int getweight_money(char* src, char* dst, int way, edge* &t_edge);//����costȨֵ
	int get_ini_time(char* src, char* dst, int way,edge* &t_edge);
	my_time get_arrivial_time(element pre,int to,int way,edge* &t_edge);
};



string minute_process(int minute)
{
	char ten_place;
	char single_place;
	string result;
	if (minute >= 10)
	{
		ten_place = (minute / 10) + '0';
		single_place = (minute - (minute / 10) * 10) + '0';
		result.push_back(ten_place);
		result.push_back(single_place);
		return result;
	}
	else
	{
		ten_place = '0';
		single_place = minute + '0';
		result.push_back(ten_place);
		result.push_back(single_place);
		return result;
	}
}







int convert_time(int d_h, int d_m, int a_h, int a_m,int dayspan)
{
	int result = 0;
	int t_hour = 0;
	int t_min;
	result += dayspan * 1440;//���շ��Ӽ���
	if (d_h <= a_h)
	{
		//û�п�Խ24��
		if(d_m<=a_m)
		t_hour = a_h - d_h;
		else
		{
			t_hour = a_h - d_h-1;
		}
	}
	else
	{
		if (d_m <= a_m)
		t_hour = 24 - d_h + a_h;
		else
		{
			t_hour = 24 - d_h + a_h - 1;
		}
	}
	if (d_m <= a_m)
	{
		t_min = a_m - d_m;
	}
	else
	{
		t_min = 60 - d_m + a_m;
	}
	result += t_min + t_hour * 60;
	return result;

}


int minus_time(my_time time1, my_time time2)
{
	//����time2-time1�ķ�����
	int result = 0;
	result = convert_time(time1.hour, time1.minute, time2.hour, time2.minute, 0);
	return result;
}



void graphlnk::show_city_routes(char* src)
{
	int v = get_index(src);
	if (v == -1) {
		cout << "û�д˳��У�" << endl; return;
	}
	vertex src_vertex = nodetable[v];
	edge *t_edge = src_vertex.adj;
	if (t_edge == nullptr) {
		cout << "û�иó��г����Ļ�/�ɻ���";
		return;
	}
	while (t_edge != nullptr)
	{
		cout << "*********************************" << endl;
		if (t_edge->type == 1)
		{
			cout << "�ɻ�Ʊ" << endl;
		}
		else cout << "��Ʊ" << endl;
		cout << "��ʼ�أ�" << src << endl;
		cout << "Ŀ�ĵأ�" <<t_edge->dest << endl;
		cout << "����ʱ��:" << t_edge->departure_time.hour << ":" << minute_process(t_edge->departure_time.minute) << endl;
		cout << "����ʱ��:" << t_edge->arrivial_time.hour << ":" << minute_process(t_edge->departure_time.minute) << endl;
		cout << "Ʊ�ۣ�" << t_edge->money << endl;
		cout << "*********************************" << endl;
		t_edge = t_edge->next;
	}
}


void graphlnk::print_city_name()
{
	int i = 0;
	for (; i < size()-1; i++)
	{
		cout << nodetable[i].name << "��";
	}
	cout << nodetable[i].name;
}



bool graphlnk::insert(char* arg_src,char* arg_dst, int arg_money, int arg_time,int type,my_time dep_time,my_time arr_time)
{
	edge* t_edge = new edge;
	int index = 0;
	int written = 0;
	int dst_in = 0;
	for (; index < nodetable.size(); index++)
	{
		if (strcmp(nodetable[index].name,arg_src)==0)
		{
			//�����Ѿ����������
			int i = 0;
			strcpy(t_edge->dest, arg_dst);
			t_edge->arrivial_time = arr_time;
			t_edge->departure_time = dep_time;
			t_edge->money = arg_money;
			t_edge->time = arg_time;
			t_edge->next = nodetable[index].adj;
			t_edge->type = type;
			nodetable[index].adj = t_edge;
			written = 1;
		}
	}
	if (!written)
	{
		vertex temp;
		strcpy(temp.name, arg_src);
		strcpy(t_edge->dest, arg_dst);
		t_edge->arrivial_time = arr_time;
		t_edge->departure_time = dep_time;
		t_edge->money = arg_money;
		t_edge->time = arg_time;
		t_edge->type = type;
		temp.adj = t_edge;
		nodetable.push_back(temp);
	}
	for (int i = 0; i < nodetable.size(); i++)
	{
		if (strcmp(nodetable[i].name, arg_dst) == 0) { dst_in = 1; break; }
	}
	if (dst_in == 1);
	else
	{
		//����û��Ŀ����еĶ���
		vertex temp;
		strcpy(temp.name, arg_dst);
		temp.adj = nullptr;
		nodetable.push_back(temp);
	}
	return true;
}

bool graphlnk::building_graph()
{
	int type;//��ͨ��������
	int departure_hour;
	int departure_min;
	int arrivial_hour;
	int arrivial_min;
	int price;
	int dayspan;//�Ƿ񾭹����쵽�
	int time=0;
	cout << "���ڽ���ͼ" << endl;
	char src[50];
	char dst[50];
	int count = 0;
	my_time dep_time;
	my_time arriv_time;
	ifstream in("ticket_info.txt", ios::in);
	if (!in.is_open())
	{
		cout << "���ļ�����" << endl;
		exit(1);
	}
	while (in >> src >> dst >> type >> departure_hour >> departure_min >> arrivial_hour >> arrivial_min >> dayspan >> price)
	{
		time = convert_time(departure_hour, departure_min, arrivial_hour, arrivial_min,dayspan);
		dep_time.hour = departure_hour;
		dep_time.minute = departure_min;
		arriv_time.hour = arrivial_hour;
		arriv_time.minute = arrivial_min;
		insert(src,dst,price, time,type,dep_time,arriv_time);
		count++;
	}
	cout << "ͼ�������" << endl;
	Vertices_num = nodetable.size();
	return true;
}



int min_vec_element(vector<int> vec)
{
	int min = vec[0];
	for (int i = 0; i < vec.size(); i++)
	{
		if (min < vec[i])min = vec[i];
	}
	return min;
}







int graphlnk::getweight_money(char* src, char* dst,int way,edge* &arg_edge)
{
	edge* t_edge;
	int min = MAXVALUE;
	for (int i = 0; i < Vertices_num; i++)
	{
		if (strcmp(src, nodetable[i].name) == 0)
		{
			t_edge = nodetable[i].adj;
			while (t_edge != nullptr)
			{
				if (strcmp(t_edge->dest, dst) == 0 && t_edge->type == way)
				{
					if (t_edge->money < min)
					{
						min = t_edge->money;
						arg_edge = t_edge;
					}
					t_edge = t_edge->next;
				}
				else
				{
					t_edge = t_edge->next;
				}
			}
			return min;
		}
	}
}



int graphlnk::get_index(char* src)
{
	for (int i = 0; i < Vertices_num; i++)
	{
		if (strcmp(src, nodetable[i].name) == 0)
		{
			return i;
		}
	}
	return -1;
}








bool graphlnk::find_shortest_path_with_money(char* src, char* dst, int dist[],element path[],int way)//rewrite
{
	bool* used = new bool[Vertices_num];
	//��ʼ����������
	int index = get_index(src);
	int min = MAXVALUE;
	int flag = 0;
	if (index == -1)
	{
		cout << "�޷�����ó���" << endl;
		return false;
	}
	if (nodetable[index].adj==nullptr)
	{
		cout << "û�иó��е���ʼ�г�������������" << endl;
		return false;
	}
	int temp_index = 0;
	int next_vertices = 0;
	edge* t_edge=nodetable[index].adj;
	for (int i = 0; i < Vertices_num; i++)
	{
		//��ʼ������
		if (strcmp(nodetable[i].name, src) == 0)
		{
			path[i].data = -1; continue;
		}
		dist[i] = getweight_money(src, nodetable[i].name,way,t_edge);
		used[i] = false;
		if (strcmp(src,nodetable[i].name)!=0 && dist[i] < MAXVALUE)
		{
			path[i].data = index;//����һ��ʼ��·��
			path[i].ticket.arrivial_time = t_edge->arrivial_time;
			path[i].ticket.departure_time = t_edge->departure_time;
			path[i].ticket.money = t_edge->money;
		}
		else
		{
			path[i].data = -1;//û��ͨ·
		}
	}
	used[index] = true;
	dist[index] = 0;

	//�ܹ�Ѱ�Ҵ���
	for (int i = 0; i < Vertices_num - 1; i++)
	{
		int min = MAXVALUE;
		int u = index;//��ǰ���ӵ����һ���������
		for (int j = 0; j < Vertices_num; j++)
		{
			//����dist�Լ�used���飬Ѱ��dist����Сֵ
			if (used[j] == false && dist[j] < min)
			{
				min = dist[j];//������СȨֵ
				u = j;//�������·������һ��������
			}
		}
		used[u] = true;//�õ��Ѿ�ʹ��
		//�������޸�path����
		for (int k = 0; k < Vertices_num; k++)
		{
			int w = getweight_money(nodetable[u].name,nodetable[k].name,way,t_edge);
			if (used[k] == false && w < MAXVALUE && dist[u] + w < dist[k])
			{
				dist[k] = dist[u] + w;//·���������
				path[k].data  = u;//k��ǰdist����Դ��Ϊu
				path[k].ticket.arrivial_time = t_edge->arrivial_time;
				path[k].ticket.departure_time = t_edge->departure_time;
				path[k].ticket.money = t_edge->money;
			}
		}
	}
}


vector<element> my_reverse(vector<element> result)
{
	vector<element> r_reverse;
	for (int i = result.size() - 1; i >= 0; i--)
	{
		r_reverse.push_back(result[i]);
	}
	return r_reverse;
}




vector<vector<element>> graphlnk::NewPath(char* src, element path[], int n,int way)
{
	//����shortestPath�õ���path���飬���v��������������·��
	//�����������һ��vector<vector<int>>
	int v = get_index(src);
	vector<vector<element>> result;
	if (v == -1)
	{
		cout << "û����Ϊ��ʼ�صĳ���"; return result;
	}
	vector<element> temp;
	element t_ele;
	my_time t_time_dep,t_time_arri;
	t_time_dep.hour = -1;
	t_time_dep.minute = -1;
	t_time_arri.minute = -1;
	t_time_arri.hour = -1;
	for (int i = 0; i < n; i++)
	{
		if (i == v)
		{
			t_ele.data = 0;
			t_ele.ticket.arrivial_time = t_time_arri;
			t_ele.ticket.departure_time = t_time_dep;
			temp.push_back(t_ele);
			result.push_back(temp);
			temp.clear();
			continue;
		}
		int cnt = 0;
		if (path[i].data == -1)
		{
			t_ele.data = -1;
			t_ele.ticket.arrivial_time = t_time_arri;
			t_ele.ticket.departure_time = t_time_dep;
			temp.push_back(t_ele);
			result.push_back(temp);
			temp.clear();
			continue;
		}
		if (path[i].data == v)
		{
			//������ָ��vԪ��
			t_ele.clean();
			t_ele.data = v;
			t_ele.ticket.arrivial_time = t_time_arri;
			t_ele.ticket.departure_time = t_time_dep;
			temp.push_back(t_ele);
			t_ele.data = i;
			t_ele.ticket.arrivial_time = path[i].ticket.arrivial_time;
			t_ele.ticket.departure_time = path[i].ticket.departure_time;
			t_ele.ticket.money = path[i].ticket.money;
			t_ele.timespan = path[i].timespan;
			temp.push_back(t_ele);
			result.push_back(temp);
			temp.clear();
		}
		else
		{
			edge* t_edge=new edge;
			int temp1 = i;
			element temp2;
			temp2.clean();
			temp2.data = i;
			temp.push_back(temp2);
			while (path[temp1].data != v)
			{
				temp.push_back(path[temp1]);
				temp1 = path[temp1].data;
			}
			//����Ŀ�ĵ�
			//���ӳ����ط���������Ϣ
			temp2.data = v;
			t_edge->arrivial_time.hour = -1;
			t_edge->departure_time.minute = -1;
			t_edge->arrivial_time.minute = -1;
			t_edge->departure_time.hour = -1;
			getweight_money(nodetable[v].name, nodetable[temp1].name,way , t_edge);
			temp2.ticket.arrivial_time = t_edge->arrivial_time;
			temp2.ticket.departure_time = t_edge->departure_time;
			temp2.ticket.money = t_edge->money;
			temp.push_back(temp2);
			temp = my_reverse(temp);
			result.push_back(temp);
			temp.clear();
			continue;
		}
	}
	return result;
}


my_time graphlnk::get_arrivial_time(element pre,int to,int way,edge*&arg_edge)
{
	//����ѡ����Сֵ�߼���pre.ticket.arrivial_time��arg_edge->departure_time��edge��Time֮����С
	
	int find_flag = 0;
	my_time result;
	int min = MAXVALUE;
	int from = pre.data;
	if (from == -1)//��ʱ˵��ͼ�Ѿ�����ͨ
		return result;
	int count_span_time = 0;
	vertex src = nodetable[from];
	vertex dst = nodetable[to];
	char* dst_name = dst.name;
	edge* t_edge=nodetable[from].adj;
	while (t_edge != nullptr)
	{
		if (strcmp(t_edge->dest, dst_name) == 0&&t_edge->type==way)
		{
			find_flag = 1;
			count_span_time = (t_edge->arrivial_time.hour * 60 + t_edge->arrivial_time.minute);
			if (t_edge->time < min)
			{
				min = t_edge->time;
				arg_edge = t_edge;
			}
			t_edge = t_edge->next;
		}
		else
		t_edge = t_edge->next;
	}
	if(find_flag)
	return arg_edge->arrivial_time;
	else
	{
		return result;
	}
	
}



int graphlnk::getweight_time(char* src, char* dst, int way,element path,my_time arriv_time, edge*& arg_edge)
{
	edge* t_edge;
	vector<int> time_vec;
	int min = MAXVALUE;
	//��Ҫ���Ǽ�dep��arri��ֵ��ʱ��Ȩֵ�ڲ�����
	for (int i = 0; i < Vertices_num; i++)
	{
		if (strcmp(src, nodetable[i].name) == 0)
		{
			t_edge = nodetable[i].adj;
			while (t_edge != nullptr)
			{
				if (strcmp(t_edge->dest, dst) == 0 && t_edge->type == way)
				{
					if (path.timespan+minus_time(arriv_time,t_edge->departure_time)+t_edge->time < min)
					{
						min = t_edge->time;
						arg_edge = t_edge;
					}
					t_edge = t_edge->next;
				}
				else
					t_edge = t_edge->next;
			}
		}
	}
	return min;
}



int graphlnk::get_ini_time(char* src, char* dst, int way,edge* &arg_edge)
{
	edge* t_edge;
	vector<int>time_vec;
	int min = MAXVALUE;
	int flag_find = 0;
	for (int i = 0; i < Vertices_num; i++)
	{
		if (strcmp(src, nodetable[i].name) == 0)
		{
			t_edge = nodetable[i].adj;
			while (t_edge != nullptr)
			{
				if (strcmp(t_edge->dest, dst) == 0 && t_edge->type == way)
				{
					flag_find = 1;
					int t_time = t_edge->arrivial_time.hour * 60 + t_edge->arrivial_time.minute;//ֱ���ж�arrivial_time��Сֵ����ѡ��
					if (t_time< min)
					{
						min = t_time;
						arg_edge = t_edge;
					}
					t_edge = t_edge->next;
				}
				else
				{
					t_edge = t_edge->next;
				}
			}
			
		}
	}
	if(flag_find)
	return minus_time(arg_edge->departure_time, arg_edge->arrivial_time);
	else
	{
		return MAXVALUE;
	}
}



bool graphlnk::find_shortest_path_with_time(char* src, char* dst, int dist[], element path[], int way)
{
	//����ʱ�䣬��̬�ı�graph�е�timeȨֵ
	bool* used = new bool[Vertices_num];
	int index = get_index(src);
	int min = MAXVALUE;
	int flag = 0;
	if (index == -1)
	{
		cout << "�޷�����ó���" << endl;
		return false;
	}
	if (nodetable[index].adj == nullptr)
	{
		cout << "û�иó��е���ʼ�г�/�ɻ�������������" << endl;
		return false;
	}
	int temp_index = 0;
	int next_vertices = 0;
	edge* t_edge = nodetable[index].adj;
	my_time arriv_time = t_edge->arrivial_time;//��ʼ��
	for (int i = 0; i < Vertices_num; i++)
	{
		//��ʼ������
		if (strcmp(nodetable[i].name, src) == 0)
		{
			path[i].data = -1; continue;
		}
		dist[i] = get_ini_time(src, nodetable[i].name, way,t_edge);
		used[i] = false;
		if (strcmp(src, nodetable[i].name) != 0 && dist[i] < MAXVALUE)
		{
			path[i].data = index;//����һ��ʼ��·��,ͬʱ���г���ʱ�䵽��ʱ��
			path[i].ticket.departure_time = t_edge->departure_time;
			path[i].ticket.arrivial_time = t_edge->arrivial_time;
			path[i].ticket.money = t_edge->money;
			path[i].timespan = minus_time(t_edge->departure_time,t_edge->arrivial_time);
		}
		else
		{
			path[i].data = -1;//û��ͨ·
		}
	}
	used[index] = true;
	dist[index] = 0;
	//�ܹ�Ѱ�Ҵ���
	for (int i = 0; i < Vertices_num - 1; i++)
	{
		int min = MAXVALUE;
		int u = index;//��ǰ���ӵ����һ���������
		for (int j = 0; j < Vertices_num; j++)
		{
			//����dist�Լ�used���飬Ѱ��dist����Сֵ
			if (used[j] == false && dist[j] < min)
			{
				min = dist[j];//������СȨֵ
				u = j;//�������·������һ��������
			}
		}
		//�����㷨��Сȡֵ��Ϊȡ�����time_count��С����ѡ��֮��
		if (i == 0)arriv_time = path[u].ticket.arrivial_time;//��һ��ѡ�񣬾��ǿ�ʼ��·��ѡ���·��
		else { arriv_time = get_arrivial_time(path[u], u, way, t_edge); }//���ﴫ��deperture_time��arrivial_time,����ض�����
		if (arriv_time.hour == -1 && arriv_time.minute == -1)continue;//��ʱ����ͨ
		nodetable[u].chosen_arrivial = arriv_time;
		used[u] = true;//�õ��Ѿ�ʹ��
		//�������޸�path����
		for (int k = 0; k < Vertices_num; k++)
		{
			//��ҪΪnodetable[u]��ֵ����ʱ��
			int w = getweight_time(nodetable[u].name, nodetable[k].name, way, path[k], arriv_time, t_edge);
			int break_time = minus_time(arriv_time, t_edge->departure_time);
			if (used[k] == false && w < MAXVALUE && dist[u] + w + break_time< dist[k])
			{
				dist[k] = dist[u] + w + break_time;//·���������
				path[k].data = u;//k��ǰdist����Դ��Ϊu,path����ṹ����¼deperture_time��arrivial_time
				path[k].ticket.departure_time = t_edge->departure_time;
				path[k].ticket.arrivial_time = t_edge->arrivial_time;
				path[k].ticket.money = t_edge->money;
				path[k].timespan = dist[k];
			}
		}
	}
}


bool graphlnk::find_shortest_path_with_less_transit(char* src, char* dst, element path[], int way)
{
	//ʵ�ַ�ʽ����α�����һ�������õ��ֹͣ����¼��ת�����������ƵϽ�˹�����㷨��·�ϵ���Ϣ�����path������
	queue<vertex> q_vertex;
	int start = 0;
	bool* visited = new bool[Vertices_num];
	for (int i = 0; i < Vertices_num; i++)
	{
		visited[i] = false;
	}
	start = get_index(src);//�õ�src����ʼλ�����
	if (start == -1)
	{
		cout << "û�иó���!"; return false;
	}
	q_vertex.push(nodetable[start]);
	visited[start] = true;
	vertex v_temp;
	bool found = false;//�Ƿ��ҵ��ļǺ�
	while (!q_vertex.empty())//��α���
	{
		v_temp = q_vertex.front();
		q_vertex.pop();
		edge *temp_edge;
		//visited[get_index(v_temp.name)] = true;
		int father_vertex_number = get_index(v_temp.name);
		while (v_temp.adj != NULL)
		{
			temp_edge = v_temp.adj;
			if (visited[get_index(v_temp.adj->dest)] == false&& temp_edge->type == way)
			{
				q_vertex.push(nodetable[get_index(v_temp.adj->dest)]);
				if (temp_edge->type == way)
				{
					visited[get_index(v_temp.adj->dest)] = true;
					int vertex_temp_number = get_index(v_temp.adj->dest);
					path[vertex_temp_number].data = father_vertex_number;
					path[vertex_temp_number].ticket.arrivial_time = temp_edge->arrivial_time;
					path[vertex_temp_number].ticket.departure_time = temp_edge->departure_time;
					path[vertex_temp_number].ticket.money = temp_edge->money;
					path[vertex_temp_number].ticket.timespan = temp_edge->time;//�����ľ��޸�path��������
					if (strcmp(v_temp.adj->dest, dst) == 0)found = true;
				}
			}
			v_temp.adj = v_temp.adj->next;
		}
	}
	return found;
}





bool graphlnk::print_name_by_index(int index)
{
	if (index != -1)
	{
		cout << nodetable[index].name; return true;
	}
	else
	{
		cout << "�޷�����ó���";
		return false;
	}
}


void filter(vector<ticket_info_for_graph> &vec)
{
	vector<ticket_info_for_graph>::const_iterator iter = vec.begin();
	while (iter != vec.end())
	{
		if (iter->arrivial_time.hour == -1 && iter->arrivial_time.minute == -1&&iter->departure_time.hour==-1&&iter->departure_time.minute==-1) 
		{
			vec.erase(iter); iter = vec.begin();
		}
		else iter++;
	}
}







void graphlnk::print_path(char* dst,vector <vector<element>> path,int way,int sign)
{
	vector<vector<ticket_info_for_graph>> storage;
	vector<ticket_info_for_graph> temp;
	ticket_info_for_graph info;
	int money_sum=0;
	for (int j = 0; j < path.size(); j++)
	{
		for (int k = 0; k < path[j].size(); k++)
		{
			info.departure_time = path[j][k].ticket.departure_time;
			info.arrivial_time = path[j][k].ticket.arrivial_time;
			info.money = path[j][k].ticket.money;
			info.timespan = path[j][k].timespan;
			temp.push_back(info);
		}
		storage.push_back(temp);
		temp.clear();
	}
	for (int i = 0; i < storage.size(); i++)
	{
		filter(storage[i]);
	}

	for (int j = 0; j < path.size(); j++)
	{
		money_sum = 0;
		int cnt = 0;
		int able = get_index(dst);
		if (able==-1||storage[able].size() == 0) 
		{
			cout << "�޷�����˵ػ��߱�������ʼ��"<<endl; return;
		}
		for (int k = 0; k < storage[j].size(); k++)
		{
			if (path[j][storage[j].size()].data == get_index(dst));
			else break;
			cout << "�����أ�";
			print_name_by_index(path[j][k].data);
			if (k < storage[j].size() - 1)
			{
				cout << "Ŀ�ĵأ�";
				print_name_by_index(path[j][k + 1].data);
			}
			else
			{
				cout << "Ŀ�ĵأ�";
				print_name_by_index(j);
			}
			if (storage[j].size() == 0) 
			{
				cout << "�޷�����˵ػ��߱�������ʼ��"; continue;
			}
			cout << "������";
			if (way == 0)cout << "��";
			else cout << "�ɻ�";
			cout << endl;
			cout << "����ʱ��:" << storage[j][cnt].departure_time.hour << ":" << minute_process(storage[j][cnt].departure_time.minute) << endl;
			cout << "����ʱ��:" << storage[j][cnt].arrivial_time.hour << ":" << minute_process(storage[j][cnt].departure_time.minute) << endl;
			cout << "Ʊ�ۣ�" << storage[j][cnt].money << "Ԫ"<< endl;
			money_sum += storage[j][cnt].money;
			cnt++;
		}
		if (cnt)
		{
			--cnt;
			if(sign==1)
			cout << "��ʱ��Ϊ" << storage[j][cnt].timespan/60<<"Сʱ,"<<storage[j][cnt].timespan%60 <<"����"<< endl;
			if(sign==0)
			cout << "�ܽ��Ϊ" << money_sum << "Ԫ" << endl;
		}
		//cout << "��������һ����Ϣ" << endl;
	}
}